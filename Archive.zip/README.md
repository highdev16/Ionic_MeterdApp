# Meter'd Project

## Intro
Meter'd is a mobile application which allows users to find parking locations, and if the spots are held with Meter'd allow users to pay for the space from their mobile device when within a certain proximity to a Beacon device. The application should also have a web portal to allow Meter'd administrators to manage user registration.

## Stake Holders
Jake Hare <jhare@launchpeer.com>

## Team
Bryan Chappell <bryan@lincs.io>
Tom Wilson
Liz Kline <liz@lincs.io>

##Mockups ­- Invision
http://invis.io/CE3P45AZ5

## Technology
Ionic Mobile Framework
Heroku

## Tools
Slack
GitHub

##Terms / Definitions


## User Stories
As a
I want to
So that
As a
I want to
So that
<a href="https://zenhub.io"><img src="https://raw.githubusercontent.com/ZenHubIO/support/master/zenhub-badge.png"></a>
