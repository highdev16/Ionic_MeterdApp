0.1.4 - June 28, 2015

* Add Envato support
* Add optional `options` parameter to more providers
* Add optional re-request for permissions to Facebook provider

0.1.3 - June 7, 2015

* Refactor code to function as submodule
* Add Family Search support

0.1.2 - May 24, 2015

* Add Windows Live Connect support
* Add Yammer support
* Add Venmo support
* Add Stripe support
* Add Rally support
* Apache Cordova Whitelist plugin is now required and is noted in the documentation

0.1.1 - May 4, 2015

* Fix InAppBrowser checks to `cordova-plugin-inappbrowser` instead of `org.apache.cordova.inappbrowser`
* Minor code cleanup

0.1.0 - March 14, 2015

* Add optional `options` parameter to implicit grant providers
* Add Spotify provider support
* Fix Facebook to use API v2.0 instead of the ending v1.0
* Fix Twitter to meet needs of changed API

0.0.9 - March 5, 2015

* Add Imgur support

0.0.8 - January 13, 2015

* Add vkontakte support
* Add ADFS support
* Add timeout to browser close

0.0.7 - January 7, 2015

* Add Magento support

0.0.6 - December 22, 2014

* Fix/Add: Nonce method to the $cordovaOauthUtility factory
* Fix: Handle browser cancel events
* Add Withings support
* Add Foursquare support

0.0.5 - December 7, 2014

* Add Salesfoce support
* Add Strava support

0.0.4 - November 22, 2014

* Add Meetup support

0.0.3 - November 20, 2014

* Add Twitter support
* Check if InAppBrowser is installed

0.0.2 - November 4, 2014

* Add LinkedIn support
* Add Instagram support
* Add Box support
* Add Reddit support
* Use implicit grant for Google service

0.0.1 - October 20, 2014

* Add Digital Ocean support
* Add Dropbox support
* Add Google support
* Add GitHub support
* Add Facebook support
